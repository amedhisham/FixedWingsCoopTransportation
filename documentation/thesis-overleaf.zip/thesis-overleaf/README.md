# Thesis text — verbatim Overleaf import

A 1:1 import of `documentation/thesis text.docx`. **The text is not edited in any
way**: no wording, spelling, punctuation, grammar or character was changed. The
only transformation is LaTeX escaping of the characters LaTeX treats as syntax
(`\ { } & % $ # _ ~ ^`), so they still *render* as themselves.

## How to get it into Overleaf

1. Overleaf → **New Project → Upload Project** → upload `thesis-overleaf.zip`.
2. Overleaf → **Menu → Compiler → LuaLaTeX**.

LuaLaTeX is required: the text contains literal Unicode (λ, ξ, ∈, ⊤, 𝑓, ᴷ, ṗ …)
that pdfLaTeX cannot typeset. `main.tex` starts with `\RequireLuaTeX`, so picking
the wrong compiler gives a clear error instead of a confusing one.

## Verified

Compiled locally with TeX Live 2026 / LuaHBTeX 1.24.0:

* 26 pages, **0 errors**, **0 missing characters** (every Unicode glyph renders).
* Every one of the 383 docx paragraphs was checked to appear verbatim in the
  generated PDF, and separately checked against the `.tex` sources.
* 3 "overfull hbox" warnings: the long pasted equation strings (e.g.
  `\mathrm{MSE}_i = \frac{1}{T}\sum...`) are single unbreakable words wider than
  the text block, so they run into the margin. Cosmetic, and it goes away when
  those get turned into real LaTeX math.

## Layout

```
main.tex                  preamble + \input of each section
sections/01-introduction.tex
sections/02-system-modelling-and-problem-formulation.tex
sections/03-learning-based-methods.tex
sections/04-methodology.tex          (incl. Imitation Learning / Phase One, Generalization)
sections/05-phase-two-methodology.tex
sections/06-references.tex
```

Section splits are at the six top-level headings only; those headings are emitted
as `\section*{...}` with their exact original text (trailing colons included).
Word bullet/numbered lists became `itemize`/`enumerate`, the reward-term table
became a `longtable`, and bold/italic runs became `\textbf`/`\textit`.

## Two preamble details worth keeping

Both were found by compiling, and both matter:

1. **Font fallback must use font NAMES, not file names.** A `.ttf`/`.otf` in the
   fallback list makes luaotfload fail with `invalid option 'ttf;-fallback'`.
   Each fallback is also probed with `\IfFontExistsTF` first, because a fallback
   font that is not installed is a *fatal* error, not a warning.
2. **TeX ligature rewriting is disabled** (`Ligatures=NoCommon`, `-tlig`).
   With it on, `'` renders as `’`, `"` as `”`, `<<` as `«` and `--` as `–` — i.e.
   the PDF would no longer match the source character for character.

Nothing has been converted to LaTeX math: pasted equations are still the raw
characters from the docx, exactly as they were.
